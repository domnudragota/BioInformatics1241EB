# Amino-acid Nutrition Summary

**Top-3 (SARS-CoV-2):** L (Leucine), V (Valine), T (Threonine)
**Top-3 (Influenza):** L (Leucine), E (Glutamic acid (glutamate)), S (Serine)

## Foods guidance (examples)

### L — Leucine
- Low in: Fruits (e.g., apples), Oils/fats (e.g., olive oil)
- Rich in: Chicken breast, Firm tofu/soy, Beef, Fish, Dairy

### V — Valine
- Low in: Fruits, Oils/fats
- Rich in: Chicken breast, Beef, Eggs, Dairy, Soy products

### T — Threonine
- Low in: Fruits, Oils/fats
- Rich in: Chicken, Dairy, Eggs, Soy

### E — Glutamic acid (glutamate)
- Low in: Fruits, Oils/fats
- Rich in: Parmesan/hard cheeses, Chicken breast, Soy products

### S — Serine
- Low in: Fruits, Oils/fats
- Rich in: Eggs, Chicken breast, Dairy, Legumes

**Sources:** USDA FoodData Central; MyFoodData (aggregates USDA FDC)
